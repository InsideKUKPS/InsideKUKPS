function goBack() {
    window.history.back();
  }
  function onSuccess(result){
    console.log("Success:"+result);
  }
   
  function onError(result) {
    console.log("Error:"+result);
  }
 
 